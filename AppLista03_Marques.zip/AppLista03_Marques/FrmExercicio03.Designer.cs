﻿namespace AppLista03_Marques
{
    partial class FrmExercicio03
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPeso = new System.Windows.Forms.TextBox();
            this.lblExercicio03 = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.pnl01 = new System.Windows.Forms.Panel();
            this.pnl02 = new System.Windows.Forms.Panel();
            this.lblResultado = new System.Windows.Forms.Label();
            this.btnSomar = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pnl01.SuspendLayout();
            this.pnl02.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtPeso
            // 
            this.txtPeso.Location = new System.Drawing.Point(36, 106);
            this.txtPeso.Multiline = true;
            this.txtPeso.Name = "txtPeso";
            this.txtPeso.Size = new System.Drawing.Size(135, 30);
            this.txtPeso.TabIndex = 0;
            this.txtPeso.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // lblExercicio03
            // 
            this.lblExercicio03.AutoSize = true;
            this.lblExercicio03.Font = new System.Drawing.Font("Microsoft YaHei UI", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio03.Location = new System.Drawing.Point(19, 38);
            this.lblExercicio03.Name = "lblExercicio03";
            this.lblExercicio03.Size = new System.Drawing.Size(141, 31);
            this.lblExercicio03.TabIndex = 1;
            this.lblExercicio03.Text = "Exercicio03";
            this.lblExercicio03.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPeso.Location = new System.Drawing.Point(31, 61);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(99, 25);
            this.lblPeso.TabIndex = 2;
            this.lblPeso.Text = "Peso(KG):";
            this.lblPeso.Click += new System.EventHandler(this.label2_Click);
            // 
            // pnl01
            // 
            this.pnl01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(185)))), ((int)(((byte)(251)))), ((int)(((byte)(192)))));
            this.pnl01.Controls.Add(this.lblExercicio03);
            this.pnl01.Location = new System.Drawing.Point(-4, 0);
            this.pnl01.Name = "pnl01";
            this.pnl01.Size = new System.Drawing.Size(486, 126);
            this.pnl01.TabIndex = 3;
            // 
            // pnl02
            // 
            this.pnl02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(251)))), ((int)(((byte)(248)))), ((int)(((byte)(204)))));
            this.pnl02.Controls.Add(this.label1);
            this.pnl02.Controls.Add(this.btnSomar);
            this.pnl02.Controls.Add(this.lblResultado);
            this.pnl02.Controls.Add(this.txtPeso);
            this.pnl02.Controls.Add(this.lblPeso);
            this.pnl02.Location = new System.Drawing.Point(2, 127);
            this.pnl02.Name = "pnl02";
            this.pnl02.Size = new System.Drawing.Size(479, 320);
            this.pnl02.TabIndex = 4;
            this.pnl02.Paint += new System.Windows.Forms.PaintEventHandler(this.pnl02_Paint);
            // 
            // lblResultado
            // 
            this.lblResultado.AutoSize = true;
            this.lblResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblResultado.Location = new System.Drawing.Point(181, 253);
            this.lblResultado.Name = "lblResultado";
            this.lblResultado.Size = new System.Drawing.Size(14, 20);
            this.lblResultado.TabIndex = 3;
            this.lblResultado.Text = "-";
            this.lblResultado.Click += new System.EventHandler(this.lblResultado_Click);
            // 
            // btnSomar
            // 
            this.btnSomar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSomar.Location = new System.Drawing.Point(39, 163);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(115, 39);
            this.btnSomar.TabIndex = 4;
            this.btnSomar.Text = "calcular";
            this.btnSomar.UseVisualStyleBackColor = true;
            this.btnSomar.Click += new System.EventHandler(this.btnSomar_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft YaHei UI", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(20, 253);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(134, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Total a Pagar";
            // 
            // FrmExercicio03
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(480, 447);
            this.Controls.Add(this.pnl02);
            this.Controls.Add(this.pnl01);
            this.Name = "FrmExercicio03";
            this.Text = "FrmExercicio03";
            this.pnl01.ResumeLayout(false);
            this.pnl01.PerformLayout();
            this.pnl02.ResumeLayout(false);
            this.pnl02.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtPeso;
        private System.Windows.Forms.Label lblExercicio03;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Panel pnl01;
        private System.Windows.Forms.Panel pnl02;
        private System.Windows.Forms.Label lblResultado;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Label label1;
    }
}