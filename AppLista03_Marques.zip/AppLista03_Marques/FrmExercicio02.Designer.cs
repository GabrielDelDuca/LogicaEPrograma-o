﻿namespace AppLista03_Marques
{
    partial class FrmExercicio02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnl01 = new System.Windows.Forms.Panel();
            this.txtValorPago = new System.Windows.Forms.TextBox();
            this.txtValorPorLitro = new System.Windows.Forms.TextBox();
            this.lblValorPago = new System.Windows.Forms.Label();
            this.lblValorPorLitro = new System.Windows.Forms.Label();
            this.btnValor = new System.Windows.Forms.Button();
            this.pnl02 = new System.Windows.Forms.Panel();
            this.lblExercicio02 = new System.Windows.Forms.Label();
            this.pnl01.SuspendLayout();
            this.pnl02.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnl01
            // 
            this.pnl01.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(202)))), ((int)(((byte)(103)))), ((int)(((byte)(2)))));
            this.pnl01.Controls.Add(this.txtValorPago);
            this.pnl01.Controls.Add(this.txtValorPorLitro);
            this.pnl01.Controls.Add(this.lblValorPago);
            this.pnl01.Controls.Add(this.lblValorPorLitro);
            this.pnl01.Controls.Add(this.btnValor);
            this.pnl01.Location = new System.Drawing.Point(-2, 106);
            this.pnl01.Name = "pnl01";
            this.pnl01.Size = new System.Drawing.Size(561, 319);
            this.pnl01.TabIndex = 4;
            // 
            // txtValorPago
            // 
            this.txtValorPago.Location = new System.Drawing.Point(132, 111);
            this.txtValorPago.Multiline = true;
            this.txtValorPago.Name = "txtValorPago";
            this.txtValorPago.Size = new System.Drawing.Size(125, 34);
            this.txtValorPago.TabIndex = 4;
            // 
            // txtValorPorLitro
            // 
            this.txtValorPorLitro.Location = new System.Drawing.Point(132, 71);
            this.txtValorPorLitro.Multiline = true;
            this.txtValorPorLitro.Name = "txtValorPorLitro";
            this.txtValorPorLitro.Size = new System.Drawing.Size(125, 34);
            this.txtValorPorLitro.TabIndex = 3;
            // 
            // lblValorPago
            // 
            this.lblValorPago.AutoSize = true;
            this.lblValorPago.Location = new System.Drawing.Point(63, 111);
            this.lblValorPago.Name = "lblValorPago";
            this.lblValorPago.Size = new System.Drawing.Size(59, 13);
            this.lblValorPago.TabIndex = 2;
            this.lblValorPago.Text = "Valor Pago";
            // 
            // lblValorPorLitro
            // 
            this.lblValorPorLitro.AutoSize = true;
            this.lblValorPorLitro.Location = new System.Drawing.Point(63, 71);
            this.lblValorPorLitro.Name = "lblValorPorLitro";
            this.lblValorPorLitro.Size = new System.Drawing.Size(72, 13);
            this.lblValorPorLitro.TabIndex = 1;
            this.lblValorPorLitro.Text = "Valor por Litro";
            // 
            // btnValor
            // 
            this.btnValor.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(18)))), ((int)(((byte)(25)))));
            this.btnValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValor.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(10)))), ((int)(((byte)(147)))), ((int)(((byte)(150)))));
            this.btnValor.Location = new System.Drawing.Point(46, 211);
            this.btnValor.Name = "btnValor";
            this.btnValor.Size = new System.Drawing.Size(137, 65);
            this.btnValor.TabIndex = 0;
            this.btnValor.Text = "Valor";
            this.btnValor.UseVisualStyleBackColor = false;
            this.btnValor.Click += new System.EventHandler(this.btnValor_Click);
            // 
            // pnl02
            // 
            this.pnl02.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(233)))), ((int)(((byte)(216)))), ((int)(((byte)(166)))));
            this.pnl02.Controls.Add(this.lblExercicio02);
            this.pnl02.Font = new System.Drawing.Font("Mongolian Baiti", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pnl02.Location = new System.Drawing.Point(0, 3);
            this.pnl02.Name = "pnl02";
            this.pnl02.Size = new System.Drawing.Size(561, 112);
            this.pnl02.TabIndex = 3;
            // 
            // lblExercicio02
            // 
            this.lblExercicio02.AutoSize = true;
            this.lblExercicio02.Font = new System.Drawing.Font("Microsoft YaHei UI", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblExercicio02.Location = new System.Drawing.Point(29, 31);
            this.lblExercicio02.Name = "lblExercicio02";
            this.lblExercicio02.Size = new System.Drawing.Size(131, 28);
            this.lblExercicio02.TabIndex = 0;
            this.lblExercicio02.Text = "Exercício01";
            // 
            // FrmExercicio02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(560, 411);
            this.Controls.Add(this.pnl01);
            this.Controls.Add(this.pnl02);
            this.Name = "FrmExercicio02";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.FrmExercicio02_Load);
            this.pnl01.ResumeLayout(false);
            this.pnl01.PerformLayout();
            this.pnl02.ResumeLayout(false);
            this.pnl02.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnl01;
        private System.Windows.Forms.TextBox txtValorPago;
        private System.Windows.Forms.TextBox txtValorPorLitro;
        private System.Windows.Forms.Label lblValorPago;
        private System.Windows.Forms.Label lblValorPorLitro;
        private System.Windows.Forms.Button btnValor;
        private System.Windows.Forms.Panel pnl02;
        private System.Windows.Forms.Label lblExercicio02;
    }
}