﻿namespace DecisãoDeExercicios
{
    partial class FrmExemplo02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.formulariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exempo01ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo02ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo03ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formulariosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // formulariosToolStripMenuItem
            // 
            this.formulariosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exempo01ToolStripMenuItem,
            this.exemplo02ToolStripMenuItem,
            this.exemplo03ToolStripMenuItem});
            this.formulariosToolStripMenuItem.Name = "formulariosToolStripMenuItem";
            this.formulariosToolStripMenuItem.Size = new System.Drawing.Size(83, 20);
            this.formulariosToolStripMenuItem.Text = "formularios ";
            // 
            // exempo01ToolStripMenuItem
            // 
            this.exempo01ToolStripMenuItem.Name = "exempo01ToolStripMenuItem";
            this.exempo01ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exempo01ToolStripMenuItem.Text = "Exemplo_01";
            this.exempo01ToolStripMenuItem.Click += new System.EventHandler(this.exempo01ToolStripMenuItem_Click);
            // 
            // exemplo02ToolStripMenuItem
            // 
            this.exemplo02ToolStripMenuItem.Name = "exemplo02ToolStripMenuItem";
            this.exemplo02ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo02ToolStripMenuItem.Text = "Exemplo_02";
            this.exemplo02ToolStripMenuItem.Click += new System.EventHandler(this.exemplo02ToolStripMenuItem_Click);
            // 
            // exemplo03ToolStripMenuItem
            // 
            this.exemplo03ToolStripMenuItem.Name = "exemplo03ToolStripMenuItem";
            this.exemplo03ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo03ToolStripMenuItem.Text = "Exemplo_03";
            this.exemplo03ToolStripMenuItem.Click += new System.EventHandler(this.exemplo03ToolStripMenuItem_Click);
            // 
            // FrmExemplo02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmExemplo02";
            this.Text = "FrmExemplo";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem formulariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exempo01ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo02ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo03ToolStripMenuItem;
    }
}