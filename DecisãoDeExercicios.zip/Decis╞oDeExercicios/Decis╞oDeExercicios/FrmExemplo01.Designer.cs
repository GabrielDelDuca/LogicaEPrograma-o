﻿namespace DecisãoDeExercicios
{
    partial class FrmExemplo01
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.formulariosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exemplo3ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(216, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(376, 34);
            this.label1.TabIndex = 0;
            this.label1.Text = "ESTRUTURA DE DECISÃO";
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.formulariosToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // formulariosToolStripMenuItem
            // 
            this.formulariosToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.exemplo1ToolStripMenuItem,
            this.exemplo2ToolStripMenuItem,
            this.exemplo3ToolStripMenuItem});
            this.formulariosToolStripMenuItem.Name = "formulariosToolStripMenuItem";
            this.formulariosToolStripMenuItem.Size = new System.Drawing.Size(82, 20);
            this.formulariosToolStripMenuItem.Text = "Formularios";
            this.formulariosToolStripMenuItem.Click += new System.EventHandler(this.formulariosToolStripMenuItem_Click);
            // 
            // exemplo1ToolStripMenuItem
            // 
            this.exemplo1ToolStripMenuItem.Name = "exemplo1ToolStripMenuItem";
            this.exemplo1ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo1ToolStripMenuItem.Text = "Exemplo 1 ";
            // 
            // exemplo2ToolStripMenuItem
            // 
            this.exemplo2ToolStripMenuItem.Name = "exemplo2ToolStripMenuItem";
            this.exemplo2ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo2ToolStripMenuItem.Text = "Exemplo 2";
            this.exemplo2ToolStripMenuItem.Click += new System.EventHandler(this.exemplo2ToolStripMenuItem_Click);
            // 
            // exemplo3ToolStripMenuItem
            // 
            this.exemplo3ToolStripMenuItem.Name = "exemplo3ToolStripMenuItem";
            this.exemplo3ToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exemplo3ToolStripMenuItem.Text = "Exemplo 3 ";
            this.exemplo3ToolStripMenuItem.Click += new System.EventHandler(this.exemplo3ToolStripMenuItem_Click);
            // 
            // FrmExemplo01
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "FrmExemplo01";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem formulariosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exemplo3ToolStripMenuItem;
    }
}

