﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExerciciosFluxogramaA
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            double produto = double.Parse(txtProduto.Text);
            double valorproduto;

            valorproduto = produto* 0.10;


            MessageBox.Show("Valor do produto " + valorproduto);
        } 

        private void txtProduto_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
