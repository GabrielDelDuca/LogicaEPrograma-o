﻿namespace ExerciciosFluxogramaA
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.llblValorPoduto = new System.Windows.Forms.Label();
            this.btnEnviar = new System.Windows.Forms.Button();
            this.txtProduto = new System.Windows.Forms.TextBox();
            this.btnSoma = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // llblValorPoduto
            // 
            this.llblValorPoduto.AutoSize = true;
            this.llblValorPoduto.Location = new System.Drawing.Point(71, 118);
            this.llblValorPoduto.Name = "llblValorPoduto";
            this.llblValorPoduto.Size = new System.Drawing.Size(85, 13);
            this.llblValorPoduto.TabIndex = 0;
            this.llblValorPoduto.Text = "Valor do produto";
            // 
            // btnEnviar
            // 
            this.btnEnviar.Location = new System.Drawing.Point(74, 194);
            this.btnEnviar.Name = "btnEnviar";
            this.btnEnviar.Size = new System.Drawing.Size(78, 33);
            this.btnEnviar.TabIndex = 1;
            this.btnEnviar.Text = "Enviar";
            this.btnEnviar.UseVisualStyleBackColor = true;
            // 
            // txtProduto
            // 
            this.txtProduto.Location = new System.Drawing.Point(74, 143);
            this.txtProduto.Multiline = true;
            this.txtProduto.Name = "txtProduto";
            this.txtProduto.Size = new System.Drawing.Size(101, 28);
            this.txtProduto.TabIndex = 2;
            this.txtProduto.TextChanged += new System.EventHandler(this.txtProduto_TextChanged);
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(158, 194);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(78, 33);
            this.btnSoma.TabIndex = 3;
            this.btnSoma.Text = "+";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(277, 299);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.txtProduto);
            this.Controls.Add(this.btnEnviar);
            this.Controls.Add(this.llblValorPoduto);
            this.Name = "Form1";
            this.Text = "ExFluxograma";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label llblValorPoduto;
        private System.Windows.Forms.Button btnEnviar;
        private System.Windows.Forms.TextBox txtProduto;
        private System.Windows.Forms.Button btnSoma;
    }
}

