﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormscalculadora
{
    public partial class formsCalculadora : Form
    {
        public formsCalculadora()
        {
            InitializeComponent();
        }

        private void formsCalculadora_Load(object sender, EventArgs e)
        {

        }

        private void lblUm_Click(object sender, EventArgs e)
        {

        }

        private void btnEnviar_Click(object sender, EventArgs e)
        {

        }


        private void txtUm_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDois_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            int n1 = int.Parse(txtNumero1.Text);
            float n2 = float.Parse(txtNumero2.Text);
            float soma;
            soma = n1 + n2;
            MessageBox.Show("Soma igual a" + soma);
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {


        }
    }
}